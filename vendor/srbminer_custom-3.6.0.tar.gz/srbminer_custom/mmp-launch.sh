#!/usr/bin/env bash
trap 'while killall srbminer_custom_bin > /dev/null 2>&1; do sleep 1; done; exit 0' SIGTERM
EXEC="./srbminer_custom_bin"
CONF_FILE="mmp-external.conf"

# ---------------- COIN MAPPER CONFIG ----------------
declare -A COIN_MAP

COIN_MAP["EXFER"]="argon2id_exfer"
COIN_MAP["POD"]="argon2d_16000"
COIN_MAP["ERG"]="autolykos2"
COIN_MAP["DCR"]="blake3_decred"
COIN_MAP["CPU"]="cpupower"
COIN_MAP["RYO"]="cryptonight_gpu"
COIN_MAP["TRTL"]="cryptonight_turtle"
COIN_MAP["BTM"]="curvehash"
COIN_MAP["ETC"]="etchash"
COIN_MAP["ETHW"]="ethash"
COIN_MAP["ETH"]="ethash"
COIN_MAP["EVR"]="evrprogpow"
COIN_MAP["FIRO"]="firopow"
COIN_MAP["IRON"]="fishhash"
COIN_MAP["RTM"]="ghostrider"
COIN_MAP["KAS"]="heavyhash"
COIN_MAP["KLS"]="karlsenhashv2"
COIN_MAP["RVN"]="kawpow"
COIN_MAP["NEOX"]="kawpow"
COIN_MAP["MINTME"]="lyra2v2_webchain"
COIN_MAP["MEWC"]="meowpow"
COIN_MAP["VKAX"]="mike"
COIN_MAP["RING"]="minotaurx"
COIN_MAP["AVN"]="minotaurx"
COIN_MAP["XLA"]="panthera"
COIN_MAP["PRL"]="pearlhash"
COIN_MAP["PHI"]="phihash"
COIN_MAP["QTC"]="qhash"
COIN_MAP["FAC"]="sha256mem"
COIN_MAP["VTC"]="verthash"
COIN_MAP["VRSC"]="verushash"
COIN_MAP["WALA"]="walahash"
COIN_MAP["XEL"]="xelishashv3"
COIN_MAP["EPIC_PP"]="progpow_epic"
COIN_MAP["SERO"]="progpow_sero"
COIN_MAP["TLS"]="progpow_telestai"
COIN_MAP["ZANO"]="progpow_zano"
COIN_MAP["ARQ"]="randomarq"
COIN_MAP["C64"]="randomc64"
COIN_MAP["EPIC_RX"]="randomepic"
COIN_MAP["JUNO"]="randomjuno"
COIN_MAP["SCASH"]="randomscash"
COIN_MAP["SNAP"]="randomsnap"
COIN_MAP["VRL"]="randomvirel"
COIN_MAP["XMR"]="randomx"
COIN_MAP["ZEPH"]="randomx"
COIN_MAP["YADA"]="randomy"
COIN_MAP["RIN"]="rinhash"
COIN_MAP["BSTY"]="yescrypt"
COIN_MAP["YTN"]="yescrypt"
COIN_MAP["SUGAR"]="yespowersugar"
COIN_MAP["BITOK"]="yespowerbitok"
COIN_MAP["MWC"]="yespowermwc"
COIN_MAP["TIDE"]="yespowertide"
COIN_MAP["EQPAY"]="yespowereqpay"
COIN_MAP["LTNCG"]="yespowerltncg"
COIN_MAP["MGPC"]="yespowermgpc"
COIN_MAP["URX"]="yespowerurx"

# ---------------- HARDWARE CAPABILITIES MAP ----------------
# Format: "HAS_CPU:HAS_GPU" (1 = True, 0 = False)
declare -A HW_MAP
HW_MAP["argon2d_16000"]="1:0"
HW_MAP["argon2d_dynamic"]="1:0"
HW_MAP["argon2id_exfer"]="1:1"
HW_MAP["autolykos2"]="0:1"
HW_MAP["blake3_decred"]="0:1"
HW_MAP["cpupower"]="1:0"
HW_MAP["cryptonight_gpu"]="1:1"
HW_MAP["cryptonight_turtle"]="1:1"
HW_MAP["curvehash"]="1:0"
HW_MAP["etchash"]="0:1"
HW_MAP["ethash"]="0:1"
HW_MAP["evrprogpow"]="0:1"
HW_MAP["firopow"]="0:1"
HW_MAP["fishhash"]="0:1"
HW_MAP["flex"]="1:0"
HW_MAP["ghostrider"]="1:0"
HW_MAP["heavyhash"]="0:1"
HW_MAP["karlsenhashv2"]="0:1"
HW_MAP["kawpow"]="0:1"
HW_MAP["lyra2v2_webchain"]="1:1"
HW_MAP["meowpow"]="0:1"
HW_MAP["mike"]="1:0"
HW_MAP["minotaurx"]="1:0"
HW_MAP["panthera"]="1:0"
HW_MAP["pearlhash"]="0:1"
HW_MAP["phihash"]="0:1"
HW_MAP["progpow_epic"]="0:1"
HW_MAP["progpow_sero"]="0:1"
HW_MAP["progpow_telestai"]="0:1"
HW_MAP["progpow_zano"]="0:1"
HW_MAP["qhash"]="0:1"
HW_MAP["randomalpha"]="1:0"
HW_MAP["randomarq"]="1:0"
HW_MAP["randomc64"]="1:0"
HW_MAP["randomepic"]="1:0"
HW_MAP["randomjuno"]="1:0"
HW_MAP["randomscash"]="1:0"
HW_MAP["randomsnap"]="1:0"
HW_MAP["randomvirel"]="1:0"
HW_MAP["randomx"]="1:0"
HW_MAP["randomy"]="1:0"
HW_MAP["randomyada"]="1:0"
HW_MAP["rinhash"]="1:0"
HW_MAP["sha256mem"]="1:1"
HW_MAP["verthash"]="0:1"
HW_MAP["verushash"]="1:0"
HW_MAP["walahash"]="0:1"
HW_MAP["xelishashv3"]="1:1"
HW_MAP["xhash"]="0:1"
HW_MAP["yescrypt"]="1:1"
HW_MAP["yescryptr16"]="1:1"
HW_MAP["yescryptr32"]="1:1"
HW_MAP["yescryptr8"]="1:1"
HW_MAP["yespower"]="1:1"
HW_MAP["yespower2b"]="1:0"
HW_MAP["yespoweradvc"]="1:0"
HW_MAP["yespowerbitok"]="1:0"
HW_MAP["yespowereqpay"]="1:0"
HW_MAP["yespowerinterchained"]="1:0"
HW_MAP["yespowerltncg"]="1:0"
HW_MAP["yespowermgpc"]="1:0"
HW_MAP["yespowermwc"]="1:0"
HW_MAP["yespowerr16"]="1:0"
HW_MAP["yespowersugar"]="1:0"
HW_MAP["yespowertide"]="1:1"
HW_MAP["yespowerurx"]="1:0"

# ---------------- INITIALIZE VARIABLES ----------------
ARGS=("$@")
FINAL_ARGS=()

POOL_VAL=""
SSL=0
USER_VAL=""
PASS_VAL=""
COIN_VAL=""
API_PORT=4444

# ---------------- PARSE GENERIC ARGS ----------------
i=0
while [[ $i -lt ${#ARGS[@]} ]]; do
    case "${ARGS[$i]}" in
        --pool)
            POOL_VAL="${ARGS[$((i+1))]}"
            ((i+=2))
            ;;
        --user)
            USER_VAL="${ARGS[$((i+1))]}"
            ((i+=2))
            ;;
        --password)
            PASS_VAL="${ARGS[$((i+1))]}"
            ((i+=2))
            ;;
        --coin)
            COIN_VAL="${ARGS[$((i+1))]}"
            ((i+=2))
            ;;
        --api-port)
            API_PORT="${ARGS[$((i+1))]}"
            ((i+=2))
            ;;
        *)
            FINAL_ARGS+=("${ARGS[$i]}")
            ((i+=1))
            ;;
    esac
done

# ---------------- DEFAULTS ----------------
[[ -z "$API_PORT" || "$API_PORT" == "0" ]] && API_PORT=4444

# ---------------- PERSIST API PORT ----------------
if grep -q '^CUSTOM_API_PORT=' "$CONF_FILE" 2>/dev/null; then
    sed -i "s/^CUSTOM_API_PORT=.*/CUSTOM_API_PORT=$API_PORT/" "$CONF_FILE"
else
    echo "CUSTOM_API_PORT=$API_PORT" >> "$CONF_FILE"
fi

# ---------------- BUILD MINER CMD ----------------
CMD=( "$EXEC" )

TARGET_ALGO=""
if [[ -n "$COIN_VAL" ]]; then
    if [[ -n "${COIN_MAP[$COIN_VAL]}" ]]; then
        TARGET_ALGO="${COIN_MAP[$COIN_VAL]}"
    else
        TARGET_ALGO=$(echo "$COIN_VAL" | tr '[:upper:]' '[:lower:]')
    fi
fi

[[ -z "$TARGET_ALGO" ]] && TARGET_ALGO="randomx"

CMD+=( --algorithm "$TARGET_ALGO" )

if [[ -n "${HW_MAP[$TARGET_ALGO]}" ]]; then
    IFS=":" read -r HAS_CPU HAS_GPU <<< "${HW_MAP[$TARGET_ALGO]}"

    if [[ "$HAS_CPU" -eq 0 ]]; then
        CMD+=( --disable-cpu )
    fi

    if [[ "$HAS_CPU" -eq 1 && "$HAS_GPU" -eq 0 ]]; then
        CMD+=( --disable-gpu )
    fi
fi

if [[ -n "$POOL_VAL" ]]; then
    FINAL_POOL="${POOL_VAL#*://}"

    if (( SSL == 1 )); then
        CMD+=( --pool "stratum+ssl://$FINAL_POOL" )
    else
        CMD+=( --pool "$POOL_VAL" )
    fi
fi
[[ -n "$USER_VAL" ]] && CMD+=( --wallet "$USER_VAL" )
[[ -n "$PASS_VAL" ]] && CMD+=( --password "$PASS_VAL" )

CMD+=( "${FINAL_ARGS[@]}" )

# ---------------- RUN ----------------
echo "Running: ${CMD[*]}"
exec "${CMD[@]}"
